import './../styles/about.scss'

export function About(){
    return (
        <div className='aboutContainer'>
            <div className='aboutQuote'>
                <h6>ABOUT US</h6>
                <h2>Why You Can Trust</h2>
                <h2><span>REITAN LAW OFFICE</span>?</h2>
            </div>
            <div className='aboutContent'>
                <p>Take the first step towards securing your legal rights and archieving your legal goals. 
                    We pride ourselves on building strong client relationships based on trust, integrity, 
                    and transparency.</p>
                <p>Our attorneys are not just legal experts, they are compassionate advocates who genuinely 
                    care about your well-being and the outcome of your case. We strive to demystify the legal process, ensuring 
                    that you are informed and empowered to make the best decisions for your unique situation.</p>
                <a href='https://api.whatsapp.com/send?phone=5511900000000&text=Ol%C3%A1%2C%20gostaria%20de%20agendar%20uma%20consulta.'>Contact us</a>
            </div>
        </div>
)}