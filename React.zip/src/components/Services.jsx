import './../styles/services.scss'
import { Buildings, Umbrella, Bank, HouseLine, UsersThree, Scales } from 'phosphor-react'

export function Services(){
    return(
        <>
        <div className='areaSection'>
                <h2>Our Legal Practice Areas</h2>
                <div className='cardContainer'>
                    <div className='card'>
                        <UsersThree size={32} className='icon'/>
                        <h3>Family Law</h3>
                        <p>Compassionate resolution for familial matters. We guide you through divorces, child custody, and more.</p>
                    </div>
                    <div className='card'>
                        <Buildings size={32} className='icon'/>
                        <h3>Business Law</h3>
                        <p>Safeguarding your business interests with expertise in contracts, disputes, and legal compliance.</p>
                    </div>
                    <div className='card'>
                        <Scales size={32} className='icon'/>
                        <h3>Civil Litigation</h3>
                        <p>Asserting your rights through legal channels, resolving disputes with effective legal representation.</p>
                    </div>
                    <div className='card'>
                        <Umbrella size={32} className='icon'/>
                        <h3>Insurance Claim</h3>
                        <p>Advocating for fair insurance settlements, ensuring you get the compensation you deserve.</p>
                    </div>
                    <div className='card'>
                        <HouseLine size={32} className='icon'/>
                        <h3>Real Estate Law</h3>
                        <p>Protecting your assets and properties, offering legal support in transactions and disputes.</p>
                    </div>
                    <div className='card'>
                        <Bank size={32} className='icon'/>
                        <h3>Finance Law</h3>
                        <p>Ensuring your financial transactions meet legal standards on regulatory compliance.</p>
                    </div>
                </div>
            </div>
        </>
    )
}