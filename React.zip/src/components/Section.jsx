import './../styles/section.scss'

export function Section(){
    return (
        <div className='bannerSection'>
            <h2>20+ Years of Experience in Various Cases</h2>
            <p>Whether you're facing a challenging court case, need assistance with legal documentation<br/> or seeking advice on legal matters, our team is here to guide you every step of the way.</p>
            <div className='experienceContainer'>
                <div className='experienceItem'>
                    <h1>1998</h1>
                    <p>Year of foundation</p>
                </div>
                <div className='experienceItem'>
                    <h1>+500</h1>
                    <p>Clients served</p>
                </div>
                <div className='experienceItem'>
                    <h1>100%</h1>
                    <p>Satisfaction with our services</p>
                </div>
                <div className='experienceItem'>
                    <h1>+1500</h1>
                    <p>Cases analyzed</p>
                </div>
            </div>
        </div>
    )
}