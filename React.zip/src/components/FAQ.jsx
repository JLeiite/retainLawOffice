import './../styles/faq.scss'
import { CaretDown } from 'phosphor-react'
import { useState } from 'react';

export function FAQ(){
    // Estados para controlar a visibilidade de cada elemento pelo ID
    const [elementVisibility, setElementVisibility] = useState({
        element1: 'hidden',
        element2: 'hidden',
        element3: 'hidden',
        element4: 'hidden',
        element5: 'hidden'
        });
          
        const toggleVisibility = (elementId) => {
            setElementVisibility((prevState) => ({
              ...prevState,
              [elementId]: prevState[elementId] === 'visible' ? 'hidden' : 'visible',
            }));
        };

    return(
        <>
            <div className='faq'>
                <h2>Frequently Asked Questions</h2>
                <div className='faqContainer'>
                    <div className='faqImage'>
                        <img src="https://t3.ftcdn.net/jpg/02/05/60/06/360_F_205600667_N6gr8oHn6du4nxH8zADIOuPpW3m1wX1A.jpg" alt="Attorney" />
                    </div>
                    <div className='faqItem'>
                        <button type="button" onClick={() => toggleVisibility('element1')}>
                            <div className='collapseContent'>
                                <span className='collapseNumber'>1</span>
                                <span className='collapseNumber'>Do I need a lawyer for minor issues?</span>
                                <span><CaretDown /></span>                                  
                            </div>
                        </button>
                        <div style={{
                            visibility: elementVisibility.element1,
                            maxHeight: elementVisibility.element1 === 'hidden' ? 0 : 'none',
                            overflow: 'hidden',
                            transition: 'max-height 0.5s ease-in-out',
                            }}>
                            <div className="faqCard">
                                Some placeholder content for the first collapse component of this multi-collapse example. This panel is hidden by default but revealed when the user activates the relevant trigger.
                            </div>
                        </div>
                        <button type="button" onClick={() => toggleVisibility('element2')}>
                            <div className='collapseContent'>
                                <span className='collapseNumber'>2</span>
                                <span className='collapseNumber'>Are virtual consultations available?</span>
                                <span><CaretDown /></span>                                  
                            </div>
                        </button>
                        <div style={{
                            visibility: elementVisibility.element2,
                            maxHeight: elementVisibility.element2 === 'hidden' ? 0 : 'none',
                            overflow: 'hidden',
                            transition: 'max-height 0.5s ease-in-out',
                            }}>
                            <div className="faqCard">
                                Some placeholder content for the first collapse component of this multi-collapse example. This panel is hidden by default but revealed when the user activates the relevant trigger.
                            </div>
                        </div>
                        <button type="button" onClick={() => toggleVisibility('element3')}>
                            <div className='collapseContent'>
                                <span className='collapseNumber'>3</span>
                                <span className='collapseNumber'>What's the average case resolution time?</span>
                                <span><CaretDown /></span>                                  
                            </div>
                        </button>
                        <div style={{
                            visibility: elementVisibility.element3,
                            maxHeight: elementVisibility.element3 === 'hidden' ? 0 : 'none',
                            overflow: 'hidden',
                            transition: 'max-height 0.5s ease-in-out',
                            }}>
                            <div className="faqCard">
                                Some placeholder content for the first collapse component of this multi-collapse example. This panel is hidden by default but revealed when the user activates the relevant trigger.
                            </div>
                        </div>
                        <button type="button" onClick={() => toggleVisibility('element4')}>
                            <div className='collapseContent'>
                                <span className='collapseNumber'>4</span>
                                <span className='collapseNumber'>What's the process for case updates?</span>
                                <span><CaretDown /></span>                                  
                            </div>
                        </button>
                        <div style={{
                            visibility: elementVisibility.element4,
                            maxHeight: elementVisibility.element4 === 'hidden' ? 0 : 'none',
                            overflow: 'hidden',
                            transition: 'max-height 0.5s ease-in-out',
                            }}>
                            <div className="faqCard">
                                Some placeholder content for the first collapse component of this multi-collapse example. This panel is hidden by default but revealed when the user activates the relevant trigger.
                            </div>
                        </div>
                        <button type="button" onClick={() => toggleVisibility('element5')}>
                            <div className='collapseContent'>
                                <span className='collapseNumber'>5</span>
                                <span className='collapseNumber'>Are court appearances always necessary?</span>
                                <span><CaretDown /></span>                                  
                            </div>
                        </button>
                        <div style={{
                            visibility: elementVisibility.element5,
                            maxHeight: elementVisibility.element5 === 'hidden' ? 0 : 'none',
                            overflow: 'hidden',
                            transition: 'max-height 0.5s ease-in-out',
                            }}>
                            <div className="faqCard">
                                Some placeholder content for the first collapse component of this multi-collapse example. This panel is hidden by default but revealed when the user activates the relevant trigger.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}