import './styles/global.scss'

import { Header } from "./components/Header"
import { Banner } from "./components/Banner"
import { Section } from "./components/Section"
import { Footer } from "./components/Footer"
import { About } from "./components/About"
import { Services } from "./components/Services"
import { FAQ } from './components/FAQ'

export function App() {
  
  return (
    <>
      <Header />
      <Banner />
      <About />
      <Section />
      <Services />
      <FAQ />
      <Footer />
    </>
    )
  }